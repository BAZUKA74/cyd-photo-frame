#include <Arduino.h>
#include <algorithm>
#include <AnimatedGIF.h>
#include <DNSServer.h>
#include <FS.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <SPI.h>
#include <TFT_eSPI.h>
#include <TJpg_Decoder.h>
#include <WebServer.h>
#include <WiFi.h>
#include <WiFiUdp.h>

namespace {
constexpr char AP_NAME[] = "CYD-PhotoFrame";
constexpr char AP_PASSWORD[] = "cyd-display";
constexpr char JPG_PATH[] = "/media.jpg";
constexpr char GIF_PATH[] = "/media.gif";
constexpr char TEMP_PATH[] = "/upload.tmp";
constexpr uint16_t DNS_PORT = 53;
constexpr uint16_t LIVE_DRAW_PORT = 4210;
constexpr uint16_t SCREEN_W = 320;
constexpr uint16_t SCREEN_H = 240;
constexpr uint8_t TOUCH_CS = 33;
constexpr uint8_t TOUCH_IRQ = 36;
constexpr uint8_t TOUCH_CLK = 25;
constexpr uint8_t TOUCH_MOSI = 32;
constexpr uint8_t TOUCH_MISO = 39;

TFT_eSPI tft;
WebServer server(80);
DNSServer dns;
WiFiUDP liveUdp;
bool liveStrokeActive = false;
uint16_t liveStrokeX = 0;
uint16_t liveStrokeY = 0;
AnimatedGIF gif;
Preferences preferences;
File gifFile;
File uploadFile;

bool gifIsOpen = false;
bool uploadSucceeded = false;
size_t uploadBytes = 0;
bool displayPending = false;
uint32_t displayAt = 0;
int gifX = 0;
int gifY = 0;
int gifCanvasW = 0;
int gifCanvasH = 0;
uint16_t *gifFrameBuffer = nullptr;
uint32_t nextGifFrameAt = 0;
uint8_t screenRotation = 1;
bool menuOpen = false;
bool deleteConfirm = false;
bool touchReady = true;
uint32_t touchReleaseAt = 0;
uint32_t pressStartedAt = 0;
bool longPressHandled = false;
bool autoBrightness = true;
uint8_t manualBrightness = 180;
uint8_t currentBrightness = 255;
uint32_t lastBrightnessAt = 0;
uint16_t lastLightRaw = 0;
uint32_t lastMenuBrightnessDrawAt = 0;
int touchStartX = 0;
int touchStartY = 0;
uint32_t lastTouchSampleAt = 0;
bool swipeOpened = false;
float touchCal[6] = {0};
bool touchCalibrated = false;

struct TouchPoint {
  int16_t x;
  int16_t y;
  int16_t z;
};

const char PAGE[] PROGMEM = R"HTML(
<!doctype html><html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CYD PhotoFrame</title><style>
*{box-sizing:border-box}body{margin:0;background:#10131a;color:#eef2ff;font:16px system-ui,sans-serif}
main{max-width:560px;margin:32px auto;padding:24px}section{background:#1b2030;border:1px solid #30384e;border-radius:18px;padding:24px}
h1{margin:0 0 8px;font-size:28px}p{line-height:1.45;color:#bdc7df}input,select{width:100%;padding:14px;background:#111622;color:#fff;border:1px solid #46506b;border-radius:10px;margin-bottom:10px}
button{width:100%;margin-top:14px;padding:14px;border:0;border-radius:10px;background:#ffc928;color:#171300;font-weight:800;font-size:16px}
.pickers{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0 10px}.pickers button{margin:0;background:#2b3347;color:#eef2ff;border:1px solid #46506b}.hidden{display:none}.filepick{display:flex;align-items:center;justify-content:center;text-align:center;padding:12px 8px;border-radius:10px;background:#2b3347;color:#eef2ff;border:1px solid #46506b;font-weight:800}.filepick input{position:absolute;width:1px;height:1px;opacity:.01}
.small{font-size:13px;color:#8995af}.bar{height:8px;background:#0d111b;border-radius:8px;overflow:hidden;margin-top:14px}.bar i{display:block;height:100%;width:0;background:#63e6be}
#msg{min-height:24px;color:#8ce99a;font-weight:600}</style></head><body><main><section>
<h1>CYD PhotoFrame</h1><p>Загрузите фотографию JPEG или анимацию GIF. JPEG автоматически уменьшится; GIF лучше подготовить размером не больше 320×240.</p>
<form id="f"><div class="pickers"><button id="galleryBtn" type="button">Из галереи</button><label class="filepick">Из файлов / GIF<input id="files" type="file"></label></div>
<input class="hidden" id="gallery" type="file" accept="image/jpeg,image/png,image/webp,image/bmp">
<p id="chosen" class="small">Файл не выбран</p>
<select id="rot"><option value="0">Поворот: 0°</option><option value="90">Поворот: 90°</option><option value="180">Поворот: 180°</option><option value="270">Поворот: 270°</option></select>
<select id="mode"><option value="stretch">Растянуть на весь экран</option><option value="cover">Заполнить с обрезкой</option><option value="contain">Вписать с полями</option></select>
<button>Подготовить и показать</button></form>
<div class="bar"><i id="bar"></i></div><p id="msg"></p>
<p class="small">Фотографии автоматически уменьшаются до 320×240 и сжимаются. GIF отправляются без изменений и должны быть меньше 1,5 МБ.</p>
<p class="small">Wi‑Fi: CYD-PhotoFrame · адрес: 192.168.4.1</p>
</section></main><script>
async function photoBlob(x,deg,fit){
 let b=await createImageBitmap(x,{imageOrientation:'from-image'}),turn=deg===90||deg===270,aw=turn?240:320,ah=turn?320:240,dw=aw,dh=ah;
 if(fit!=='stretch'){let s=(fit==='cover'?Math.max:Math.min)(aw/b.width,ah/b.height);dw=b.width*s;dh=b.height*s;}
 let c=document.createElement('canvas');c.width=320;c.height=240;let q=c.getContext('2d');q.fillStyle='#000';q.fillRect(0,0,320,240);q.translate(160,120);q.rotate(deg*Math.PI/180);q.drawImage(b,-dw/2,-dh/2,dw,dh);b.close();
 return await new Promise(ok=>c.toBlob(ok,'image/jpeg',.86));
}
async function isGifFile(x){
 if(x.type==='image/gif'||x.name.toLowerCase().endsWith('.gif'))return true;
 try{let a=new Uint8Array(await x.slice(0,6).arrayBuffer());return String.fromCharCode(...a)==='GIF87a'||String.fromCharCode(...a)==='GIF89a';}catch(e){return false;}
}
let chosenFile=null,chosenIsGif=false;
galleryBtn.onclick=()=>gallery.click();
function picked(input,forceGif){if(!input.files[0])return;chosenFile=input.files[0];chosenIsGif=forceGif;chosen.textContent=chosenFile.name;msg.textContent='';}
gallery.onchange=()=>picked(gallery,false);files.onchange=()=>picked(files,true);
f.onsubmit=async e=>{e.preventDefault();let x=chosenFile;if(!x){msg.textContent='Сначала выберите фотографию или GIF';return;}bar.style.width='0';msg.textContent='Подготовка фотографии…';
 try{let isGif=chosenIsGif||await isGifFile(x),blob=isGif?x:await photoBlob(x,+rot.value,mode.value);if(!blob)throw Error();
  msg.textContent=isGif?'Загрузка GIF…':`Сжато: ${Math.ceil(blob.size/1024)} КБ. Загрузка…`;let d=new FormData();d.append('media',blob,isGif?'media.gif':'photo.jpg');let r=new XMLHttpRequest();
  r.open('POST','/upload');r.upload.onprogress=e=>{if(e.lengthComputable)bar.style.width=(e.loaded/e.total*100)+'%'};
  r.onload=()=>{msg.textContent=r.responseText;bar.style.width=r.status==200?'100%':'0'};r.onerror=()=>msg.textContent='Ошибка соединения';r.onloadend=()=>{gallery.value='';files.value='';chosenFile=null;chosenIsGif=false;chosen.textContent='Файл не выбран'};r.send(d);
 }catch(err){msg.textContent='Не удалось обработать эту фотографию';}
};
</script></body></html>)HTML";

void closeGif() {
  if (gifIsOpen) {
    gif.close();
    gifIsOpen = false;
  }
  if (gifFrameBuffer) {
    free(gifFrameBuffer);
    gifFrameBuffer = nullptr;
  }
}

void showMessage(const String &title, const String &line1 = "", const String &line2 = "") {
  closeGif();
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_YELLOW, TFT_BLACK);
  tft.drawString(title, SCREEN_W / 2, 72, 4);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString(line1, SCREEN_W / 2, 125, 2);
  tft.drawString(line2, SCREEN_W / 2, 151, 2);
}

bool jpegOutput(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t *pixels) {
  if (x >= SCREEN_W || y >= SCREEN_H) return false;
  tft.pushImage(x, y, w, h, pixels);
  return true;
}

void *gifOpenFile(const char *name, int32_t *size) {
  gifFile = LittleFS.open(name, "r");
  if (!gifFile) return nullptr;
  *size = static_cast<int32_t>(gifFile.size());
  return &gifFile;
}

void gifCloseFile(void *handle) {
  File *file = static_cast<File *>(handle);
  if (file) file->close();
}

int32_t gifReadFile(GIFFILE *fileInfo, uint8_t *buffer, int32_t length) {
  File *file = static_cast<File *>(fileInfo->fHandle);
  int32_t remaining = fileInfo->iSize - fileInfo->iPos;
  if (remaining < length) length = remaining;
  if (length <= 0) return 0;
  int32_t count = static_cast<int32_t>(file->read(buffer, length));
  fileInfo->iPos = static_cast<int32_t>(file->position());
  return count;
}

int32_t gifSeekFile(GIFFILE *fileInfo, int32_t position) {
  File *file = static_cast<File *>(fileInfo->fHandle);
  file->seek(position);
  fileInfo->iPos = static_cast<int32_t>(file->position());
  return fileInfo->iPos;
}

void gifDraw(GIFDRAW *draw) {
  uint8_t *source = draw->pPixels;
  uint16_t *palette = draw->pPalette;
  uint16_t line[SCREEN_W];
  int width = draw->iWidth;
  int xBase = draw->iX;
  int y = draw->iY + draw->y;

  if (gifFrameBuffer) {
    if (xBase < 0) {
      source -= xBase;
      width += xBase;
      xBase = 0;
    }
    if (xBase + width > gifCanvasW) width = gifCanvasW - xBase;
    if (y < 0 || y >= gifCanvasH || width <= 0) return;
    uint16_t *dest = gifFrameBuffer + y * gifCanvasW + xBase;
    const uint8_t transparent = draw->ucTransparent;
    for (int x = 0; x < width; ++x) {
      if (!draw->ucHasTransparency || source[x] != transparent) {
        dest[x] = palette[source[x]];
      } else if (draw->ucDisposalMethod == 2) {
        dest[x] = palette[draw->ucBackground];
      }
    }
    return;
  }

  xBase += gifX;
  y += gifY;

  if (xBase < 0) {
    source -= xBase;
    width += xBase;
    xBase = 0;
  }
  if (xBase + width > SCREEN_W) width = SCREEN_W - xBase;
  if (y < 0 || y >= SCREEN_H || width <= 0) return;

  if (draw->ucDisposalMethod == 2) {
    for (int x = 0; x < width; ++x) {
      if (source[x] == draw->ucTransparent) source[x] = draw->ucBackground;
    }
    draw->ucHasTransparency = 0;
  }

  if (!draw->ucHasTransparency) {
    for (int x = 0; x < width; ++x) line[x] = palette[source[x]];
    tft.pushImage(xBase, y, width, 1, line);
    return;
  }

  const uint8_t transparent = draw->ucTransparent;
  int x = 0;
  while (x < width) {
    while (x < width && source[x] == transparent) ++x;
    const int start = x;
    while (x < width && source[x] != transparent) {
      line[x - start] = palette[source[x]];
      ++x;
    }
    if (x > start) tft.pushImage(xBase + start, y, x - start, 1, line);
  }
}

bool openGif() {
  closeGif();
  if (!LittleFS.exists(GIF_PATH)) return false;
  // AnimatedGIF in BIG_ENDIAN_PIXELS mode already produces display-order RGB565.
  tft.setSwapBytes(false);
  if (!gif.open(GIF_PATH, gifOpenFile, gifCloseFile, gifReadFile, gifSeekFile, gifDraw)) return false;
  gifX = (SCREEN_W - gif.getCanvasWidth()) / 2;
  gifY = (SCREEN_H - gif.getCanvasHeight()) / 2;
  gifCanvasW = gif.getCanvasWidth();
  gifCanvasH = gif.getCanvasHeight();
  if (gifCanvasW > 0 && gifCanvasH > 0 && gifCanvasW <= SCREEN_W && gifCanvasH <= SCREEN_H) {
    const size_t bytes = static_cast<size_t>(gifCanvasW) * gifCanvasH * sizeof(uint16_t);
    gifFrameBuffer = static_cast<uint16_t *>(malloc(bytes));
    if (gifFrameBuffer) memset(gifFrameBuffer, 0, bytes);
  }
  gifIsOpen = true;
  nextGifFrameAt = 0;
  return true;
}

void showJpeg() {
  closeGif();
  tft.setSwapBytes(true);
  uint16_t width = 0, height = 0;
  if (TJpgDec.getFsJpgSize(&width, &height, JPG_PATH, LittleFS) != JDR_OK || width == 0 || height == 0) {
    showMessage("JPEG error", "Файл не удалось прочитать");
    return;
  }
  uint8_t scale = 1;
  while (scale < 8 && (width / scale > SCREEN_W || height / scale > SCREEN_H)) scale *= 2;
  TJpgDec.setJpgScale(scale);
  const int x = (SCREEN_W - static_cast<int>(width / scale)) / 2;
  const int y = (SCREEN_H - static_cast<int>(height / scale)) / 2;
  tft.fillScreen(TFT_BLACK);
  TJpgDec.drawFsJpg(max(0, x), max(0, y), JPG_PATH, LittleFS);
}

void showStoredMedia() {
  if (LittleFS.exists(GIF_PATH)) {
    tft.fillScreen(TFT_BLACK);
    if (!openGif()) showMessage("GIF error", "Файл не удалось прочитать");
  } else if (LittleFS.exists(JPG_PATH)) {
    showJpeg();
  } else {
    showMessage("CYD PhotoFrame", "Wi-Fi: CYD-PhotoFrame", "Откройте 192.168.4.1");
  }
}

void setBacklight(uint8_t value) {
  currentBrightness = value;
  ledcWrite(TFT_BL, value);
}

void updateAutomaticBrightness() {
  if (millis() - lastBrightnessAt < 50) return;
  lastBrightnessAt = millis();
  static uint32_t filtered = 0;
  const uint16_t raw = analogRead(34);
  lastLightRaw = raw;
  filtered = filtered == 0 ? raw * 8UL : (filtered * 3UL + raw * 8UL) / 4UL;
  const uint16_t smooth = filtered / 8UL;
  if (autoBrightness) {
    // The LDR on this HW-458 board uses only a part of the ESP32 ADC range.
    // Calibrated for a useful visible response from a covered sensor to a torch.
    setBacklight(static_cast<uint8_t>(constrain(map(smooth, 300, 1800, 255, 15), 15L, 255L)));
  }
  static uint32_t lastLogAt = 0;
  if (millis() - lastLogAt >= 1000) {
    lastLogAt = millis();
    Serial.printf("Light sensor: %u, backlight: %u, auto: %s\n",
                  lastLightRaw, currentBrightness, autoBrightness ? "ON" : "OFF");
  }
}

void drawBrightnessSlider() {
  constexpr uint16_t border = 0x4208;
  const uint8_t shown = autoBrightness ? currentBrightness : manualBrightness;
  const int knobX = map(shown, 0, 255, 34, 286);
  tft.fillRect(20, 84, 280, 45, TFT_BLACK);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(0x9cf3, TFT_BLACK);
  tft.drawString(autoBrightness ? "BRIGHTNESS  AUTO" : "BRIGHTNESS", 20, 92, 2);
  tft.fillRoundRect(34, 113, 252, 4, 2, border);
  tft.fillCircle(knobX, 115, 8, TFT_WHITE);
}

void drawTouchMenu() {
  closeGif();
  menuOpen = true;
  deleteConfirm = false;
  constexpr uint16_t panel = 0x1082;
  constexpr uint16_t border = 0x4208;
  constexpr uint16_t muted = 0x9cf3;
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(muted, TFT_BLACK);
  tft.drawString("SETTINGS", 16, 18, 2);
  tft.setTextDatum(MR_DATUM);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("CLOSE", 304, 18, 2);

  tft.fillRoundRect(16, 38, 288, 40, 6, panel);
  tft.drawRoundRect(16, 38, 288, 40, 6, border);
  tft.setTextDatum(ML_DATUM);
  tft.drawString(String("AUTO BRIGHTNESS  ") + lastLightRaw, 28, 58, 2);
  tft.fillRoundRect(244, 49, 44, 20, 10, autoBrightness ? 0x2e69 : border);
  tft.fillCircle(autoBrightness ? 278 : 254, 59, 8, TFT_WHITE);
  drawBrightnessSlider();

  tft.fillRoundRect(16, 136, 288, 38, 6, panel);
  tft.drawRoundRect(16, 136, 288, 38, 6, border);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("ROTATE 180", 160, 155, 2);

  tft.fillRoundRect(16, 188, 288, 38, 6, panel);
  tft.drawRoundRect(16, 188, 288, 38, 6, 0xb104);
  tft.setTextColor(0xfd75, panel);
  tft.drawString("DELETE PHOTO", 160, 207, 2);
}

void updateMenuBrightnessDisplay() {
  if (!menuOpen || deleteConfirm || millis() - lastMenuBrightnessDrawAt < 100) return;
  lastMenuBrightnessDrawAt = millis();
  constexpr uint16_t panel = 0x1082;
  tft.fillRect(24, 47, 207, 23, panel);
  tft.setTextDatum(ML_DATUM);
  tft.setTextColor(TFT_WHITE, panel);
  tft.drawString(String("LIGHT ") + lastLightRaw + "  LEVEL " + currentBrightness, 28, 58, 2);
  drawBrightnessSlider();
}

void drawDeleteConfirmation() {
  deleteConfirm = true;
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("DELETE THIS PHOTO?", 160, 35, 2);
  tft.fillRoundRect(16, 70, 288, 58, 6, 0x1082);
  tft.drawRoundRect(16, 70, 288, 58, 6, 0x4208);
  tft.drawString("CANCEL", 160, 99, 2);
  tft.fillRoundRect(16, 150, 288, 58, 6, 0x1082);
  tft.drawRoundRect(16, 150, 288, 58, 6, 0xb104);
  tft.setTextColor(0xfd75, 0x1082);
  tft.drawString("DELETE", 160, 179, 2);
}

uint16_t touchTransfer(uint8_t command) {
  digitalWrite(TOUCH_CS, LOW);
  for (int bit = 7; bit >= 0; --bit) {
    digitalWrite(TOUCH_MOSI, (command >> bit) & 1);
    digitalWrite(TOUCH_CLK, HIGH);
    digitalWrite(TOUCH_CLK, LOW);
  }
  uint16_t value = 0;
  for (int bit = 0; bit < 16; ++bit) {
    digitalWrite(TOUCH_CLK, HIGH);
    value = static_cast<uint16_t>((value << 1) | digitalRead(TOUCH_MISO));
    digitalWrite(TOUCH_CLK, LOW);
  }
  digitalWrite(TOUCH_CS, HIGH);
  return (value >> 3) & 0x0fff;
}

TouchPoint readTouchPoint() {
  uint16_t xs[3], ys[3];
  for (int i = 0; i < 3; ++i) {
    xs[i] = touchTransfer(0xd0);
    ys[i] = touchTransfer(0x90);
  }
  auto median3 = [](uint16_t a, uint16_t b, uint16_t c) {
    if (a > b) std::swap(a, b);
    if (b > c) std::swap(b, c);
    if (a > b) std::swap(a, b);
    return b;
  };
  return {static_cast<int16_t>(median3(xs[0], xs[1], xs[2])),
          static_cast<int16_t>(median3(ys[0], ys[1], ys[2])), 1000};
}

TouchPoint waitForCalibrationTap(int targetX, int targetY, int step) {
  tft.fillScreen(TFT_BLACK);
  tft.setTextDatum(MC_DATUM);
  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.drawString("TOUCH CALIBRATION", 160, 108, 2);
  tft.setTextColor(0x9cf3, TFT_BLACK);
  tft.drawString(String("Tap cross ") + step + "/3", 160, 132, 2);
  tft.drawLine(targetX - 12, targetY, targetX + 12, targetY, TFT_RED);
  tft.drawLine(targetX, targetY - 12, targetX, targetY + 12, TFT_RED);
  tft.drawCircle(targetX, targetY, 7, TFT_RED);

  while (digitalRead(TOUCH_IRQ) == LOW) delay(10);
  delay(150);
  while (digitalRead(TOUCH_IRQ) != LOW) delay(5);
  delay(40);
  TouchPoint point = readTouchPoint();
  while (digitalRead(TOUCH_IRQ) == LOW) delay(10);
  delay(180);
  return point;
}

void calibrateTouch() {
  const uint8_t savedRotation = screenRotation;
  tft.setRotation(1);
  setBacklight(220);
  const int sx[3] = {24, 296, 24};
  const int sy[3] = {24, 24, 216};
  TouchPoint raw[3];
  for (int i = 0; i < 3; ++i) raw[i] = waitForCalibrationTap(sx[i], sy[i], i + 1);

  const float x1 = raw[0].x, y1 = raw[0].y;
  const float x2 = raw[1].x, y2 = raw[1].y;
  const float x3 = raw[2].x, y3 = raw[2].y;
  const float det = x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2);
  if (fabs(det) > 1.0f) {
    touchCal[0] = (sx[0] * (y2 - y3) + sx[1] * (y3 - y1) + sx[2] * (y1 - y2)) / det;
    touchCal[1] = (sx[0] * (x3 - x2) + sx[1] * (x1 - x3) + sx[2] * (x2 - x1)) / det;
    touchCal[2] = (sx[0] * (x2 * y3 - x3 * y2) + sx[1] * (x3 * y1 - x1 * y3) +
                   sx[2] * (x1 * y2 - x2 * y1)) / det;
    touchCal[3] = (sy[0] * (y2 - y3) + sy[1] * (y3 - y1) + sy[2] * (y1 - y2)) / det;
    touchCal[4] = (sy[0] * (x3 - x2) + sy[1] * (x1 - x3) + sy[2] * (x2 - x1)) / det;
    touchCal[5] = (sy[0] * (x2 * y3 - x3 * y2) + sy[1] * (x3 * y1 - x1 * y3) +
                   sy[2] * (x1 * y2 - x2 * y1)) / det;
    preferences.putBytes("touchcal", touchCal, sizeof(touchCal));
    preferences.putUChar("calver", 2);
    touchCalibrated = true;
  }
  tft.setRotation(savedRotation);
  setBacklight(autoBrightness ? 180 : manualBrightness);
}

void mapTouchPoint(const TouchPoint &point, int &x, int &y) {
  if (touchCalibrated) {
    x = constrain(static_cast<int>(touchCal[0] * point.x + touchCal[1] * point.y + touchCal[2]), 0, SCREEN_W - 1);
    y = constrain(static_cast<int>(touchCal[3] * point.x + touchCal[4] * point.y + touchCal[5]), 0, SCREEN_H - 1);
  } else {
    x = constrain(map(point.x, 3860, 280, 0, SCREEN_W), 0L, static_cast<long>(SCREEN_W - 1));
    y = constrain(map(point.y, 3860, 340, 0, SCREEN_H), 0L, static_cast<long>(SCREEN_H - 1));
  }
  if (screenRotation == 3) {
    x = SCREEN_W - 1 - x;
    y = SCREEN_H - 1 - y;
  }
}

void handleMenuPosition(int x, int y) {
  Serial.printf("Touch screen=%d,%d\n", x, y);
  if (deleteConfirm) {
    if (y < 140) {
      drawTouchMenu();
    } else {
      closeGif();
      LittleFS.remove(JPG_PATH);
      LittleFS.remove(GIF_PATH);
      menuOpen = false;
      deleteConfirm = false;
      showMessage("PHOTO DELETED", "Swipe down for settings");
    }
  } else if (y < 34 && x > 235) {
    menuOpen = false;
    longPressHandled = true;
    swipeOpened = true;
    showStoredMedia();
  } else if (x >= 220 && y >= 36 && y < 82) {
    autoBrightness = !autoBrightness;
    preferences.putBool("auto", autoBrightness);
    if (!autoBrightness) setBacklight(manualBrightness);
    drawTouchMenu();
  } else if (y >= 82 && y < 132) {
    manualBrightness = static_cast<uint8_t>(constrain(map(x, 34, 286, 15, 255), 15L, 255L));
    autoBrightness = false;
    preferences.putBool("auto", false);
    preferences.putUChar("bright", manualBrightness);
    setBacklight(manualBrightness);
    drawBrightnessSlider();
  } else if (y >= 132 && y < 182) {
    screenRotation = screenRotation == 1 ? 3 : 1;
    preferences.putUChar("rotation", screenRotation);
    tft.setRotation(screenRotation);
    menuOpen = false;
    showStoredMedia();
  } else if (y >= 182) {
    drawDeleteConfirmation();
  }
}

void handleTouch() {
  const bool down = digitalRead(TOUCH_IRQ) == LOW;
  if (down) touchReleaseAt = 0;

  if (down && touchReady) {
    touchReady = false;
    pressStartedAt = millis();
    lastTouchSampleAt = millis();
    longPressHandled = false;
    swipeOpened = false;
    TouchPoint point = readTouchPoint();
    mapTouchPoint(point, touchStartX, touchStartY);
    if (menuOpen) handleMenuPosition(touchStartX, touchStartY);
  }

  if (down && !touchReady && millis() - lastTouchSampleAt >= 35) {
    lastTouchSampleAt = millis();
    TouchPoint point = readTouchPoint();
    int x = 0, y = 0;
    mapTouchPoint(point, x, y);
    if (!menuOpen && !swipeOpened && touchStartY < 65 && y - touchStartY > 65) {
      swipeOpened = true;
      longPressHandled = true;
      drawTouchMenu();
    } else if (menuOpen && !swipeOpened && !deleteConfirm && y >= 82 && y < 132) {
      handleMenuPosition(x, y);
    }
  }

  if (down && !touchReady && !menuOpen && !longPressHandled && millis() - pressStartedAt >= 900) {
    longPressHandled = true;
    drawTouchMenu();
  }

  if (!down && !touchReady) {
    if (touchReleaseAt == 0) touchReleaseAt = millis();
    if (millis() - touchReleaseAt >= 80) {
      touchReady = true;
      touchReleaseAt = 0;
      longPressHandled = false;
    }
  }
}

void finishUpload() {
  if (uploadFile) uploadFile.close();
  if (!uploadSucceeded || uploadBytes < 6) {
    LittleFS.remove(TEMP_PATH);
    server.send(400, "text/plain; charset=utf-8", "Загрузка не удалась или файл слишком большой");
    showStoredMedia();
    return;
  }

  File probe = LittleFS.open(TEMP_PATH, "r");
  uint8_t header[6] = {};
  probe.read(header, sizeof(header));
  probe.close();
  const bool isJpeg = header[0] == 0xff && header[1] == 0xd8;
  const bool isGif = memcmp(header, "GIF87a", 6) == 0 || memcmp(header, "GIF89a", 6) == 0;
  if (!isJpeg && !isGif) {
    LittleFS.remove(TEMP_PATH);
    server.send(415, "text/plain; charset=utf-8", "Поддерживаются только JPEG и GIF");
    showStoredMedia();
    return;
  }

  LittleFS.remove(JPG_PATH);
  LittleFS.remove(GIF_PATH);
  const char *target = isGif ? GIF_PATH : JPG_PATH;
  if (!LittleFS.rename(TEMP_PATH, target)) {
    server.send(500, "text/plain; charset=utf-8", "Не удалось сохранить файл");
    showStoredMedia();
    return;
  }
  server.sendHeader("Connection", "close");
  server.send(200, "text/plain; charset=utf-8", isGif ? "GIF загружен и запущен" : "Фотография загружена");
  displayPending = true;
  displayAt = millis() + 500;
}

void receiveUpload() {
  HTTPUpload &upload = server.upload();
  if (upload.status == UPLOAD_FILE_START) {
    displayPending = false;
    closeGif();
    // Free the old media before receiving the replacement. Otherwise LittleFS
    // temporarily needs enough room for both files and rejects larger GIFs.
    LittleFS.remove(JPG_PATH);
    LittleFS.remove(GIF_PATH);
    LittleFS.remove(TEMP_PATH);
    uploadFile = LittleFS.open(TEMP_PATH, "w");
    uploadSucceeded = static_cast<bool>(uploadFile);
    uploadBytes = 0;
    showMessage("Uploading...", "Не отключайте питание");
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (uploadSucceeded) {
      const size_t written = uploadFile.write(upload.buf, upload.currentSize);
      uploadBytes += written;
      if (written != upload.currentSize) uploadSucceeded = false;
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (uploadFile) uploadFile.close();
  } else if (upload.status == UPLOAD_FILE_ABORTED) {
    uploadSucceeded = false;
    if (uploadFile) uploadFile.close();
    LittleFS.remove(TEMP_PATH);
  }
}

void setupWeb() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AP_NAME, AP_PASSWORD);
  dns.start(DNS_PORT, "*", WiFi.softAPIP());
  server.on("/", HTTP_GET, [] {
    server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
    server.sendHeader("Pragma", "no-cache");
    server.send_P(200, "text/html; charset=utf-8", PAGE);
  });
  server.on("/upload", HTTP_POST, finishUpload, receiveUpload);
  server.onNotFound([] { server.sendHeader("Location", "http://192.168.4.1/", true); server.send(302, "text/plain", ""); });
  server.begin();
  liveUdp.begin(LIVE_DRAW_PORT);
}

void handleLiveDrawing() {
  int packetSize = liveUdp.parsePacket();
  while (packetSize > 0) {
    uint8_t packet[16] = {};
    const int count = liveUdp.read(packet, sizeof(packet));
    if (count >= 1 && packet[0] == 2) {
      closeGif();
      displayPending = false;
      menuOpen = false;
      liveStrokeActive = false;
      tft.fillScreen(TFT_WHITE);
    } else if (count >= 5 && packet[0] == 3) {
      liveStrokeX = min<uint16_t>(packet[1] | (packet[2] << 8), SCREEN_W - 1);
      liveStrokeY = min<uint16_t>(packet[3] | (packet[4] << 8), SCREEN_H - 1);
      liveStrokeActive = true;
    } else if (count >= 9 && packet[0] == 1) {
      const uint16_t x1 = packet[1] | (packet[2] << 8);
      const uint16_t y1 = packet[3] | (packet[4] << 8);
      const uint16_t x2 = packet[5] | (packet[6] << 8);
      const uint16_t y2 = packet[7] | (packet[8] << 8);
      const uint16_t color = count >= 13 ? tft.color565(packet[9], packet[10], packet[11]) : TFT_BLACK;
      const uint8_t width = count >= 13 ? constrain(packet[12], 2, 16) : 5;
      const uint16_t endX = min<uint16_t>(x2, SCREEN_W - 1);
      const uint16_t endY = min<uint16_t>(y2, SCREEN_H - 1);
      const uint16_t startX = liveStrokeActive ? liveStrokeX : min<uint16_t>(x1, SCREEN_W - 1);
      const uint16_t startY = liveStrokeActive ? liveStrokeY : min<uint16_t>(y1, SCREEN_H - 1);
      tft.drawWideLine(startX, startY, endX, endY, width, color);
      liveStrokeX = endX;
      liveStrokeY = endY;
      liveStrokeActive = true;
    }
    packetSize = liveUdp.parsePacket();
  }
}
}  // namespace

void setup() {
  Serial.begin(115200);
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);
  tft.init();
  ledcAttach(TFT_BL, 1000, 8);
  preferences.begin("photoframe", false);
  screenRotation = preferences.getUChar("rotation", 1);
  if (screenRotation != 1 && screenRotation != 3) screenRotation = 1;
  autoBrightness = preferences.getBool("auto", true);
  if (preferences.getUChar("autover", 0) < 1) {
    autoBrightness = true;
    preferences.putBool("auto", true);
    preferences.putUChar("autover", 1);
  }
  manualBrightness = preferences.getUChar("bright", 180);
  tft.setRotation(screenRotation);
  tft.setSwapBytes(true);
  tft.fillScreen(TFT_BLACK);

  if (!LittleFS.begin(true)) {
    showMessage("Storage error", "LittleFS не запустилась");
    return;
  }

  TJpgDec.setCallback(jpegOutput);
  gif.begin(BIG_ENDIAN_PIXELS);
  pinMode(TOUCH_CS, OUTPUT);
  pinMode(TOUCH_CLK, OUTPUT);
  pinMode(TOUCH_MOSI, OUTPUT);
  pinMode(TOUCH_MISO, INPUT);
  pinMode(TOUCH_IRQ, INPUT);
  pinMode(34, INPUT);
  digitalWrite(TOUCH_CS, HIGH);
  digitalWrite(TOUCH_CLK, LOW);
  setBacklight(autoBrightness ? 180 : manualBrightness);
  if (preferences.getUChar("calver", 0) == 2 &&
      preferences.getBytesLength("touchcal") == sizeof(touchCal)) {
    preferences.getBytes("touchcal", touchCal, sizeof(touchCal));
    touchCalibrated = true;
  } else {
    calibrateTouch();
  }
  setupWeb();
  showStoredMedia();

  Serial.printf("Wi-Fi: %s\nPassword: %s\nOpen: http://%s/\n", AP_NAME, AP_PASSWORD,
                WiFi.softAPIP().toString().c_str());
}

void loop() {
  dns.processNextRequest();
  server.handleClient();
  handleLiveDrawing();
  handleTouch();
  updateAutomaticBrightness();
  updateMenuBrightnessDisplay();

  if (displayPending && static_cast<int32_t>(millis() - displayAt) >= 0) {
    displayPending = false;
    showStoredMedia();
  }

  if (gifIsOpen && static_cast<int32_t>(millis() - nextGifFrameAt) >= 0) {
    int frameDelay = 0;
    if (gif.playFrame(false, &frameDelay)) {
      if (gifFrameBuffer) {
        tft.startWrite();
        tft.pushImage(gifX, gifY, gifCanvasW, gifCanvasH, gifFrameBuffer);
        tft.endWrite();
      }
      nextGifFrameAt = millis() + max(frameDelay, 10);
    } else {
      openGif();
    }
  }
  delay(1);
}
