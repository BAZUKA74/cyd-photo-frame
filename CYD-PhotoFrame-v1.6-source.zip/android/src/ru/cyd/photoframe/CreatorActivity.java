package ru.cyd.photoframe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CreatorActivity extends Activity {
    DrawPad pad; EditText text; TextView state;
    volatile boolean live=false; Button liveButton; DatagramSocket liveSocket; InetAddress boardAddress;
    final ExecutorService liveQueue=Executors.newSingleThreadExecutor();
    int brushColor=Color.BLACK; float brushWidth=5; boolean moveText=false; float textX=160,textY=222,textSize=32;String committedText="";
    @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(18),dp(16),dp(16));root.setBackgroundColor(Color.rgb(16,19,26));
        TextView title=label("ХОЛСТ И ТЕКСТ",25,Color.WHITE);root.addView(title);TextView hint=label("Рисуйте пальцем на белом поле. Текст появится по буквам после рисунка.",14,Color.rgb(180,192,216));hint.setPadding(0,dp(6),0,dp(10));root.addView(hint);
        pad=new DrawPad();root.addView(pad,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout textRow=new LinearLayout(this);text=new EditText(this);text.setHint("Введите текст");text.setSingleLine(true);text.setTextColor(Color.BLACK);text.setHintTextColor(Color.DKGRAY);text.setBackground(round(Color.WHITE,10));text.setPadding(dp(12),0,dp(12),0);LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,dp(50),1);ep.setMargins(0,dp(10),dp(5),dp(5));textRow.addView(text,ep);Button enter=button("Ввод",Color.rgb(255,201,40),Color.BLACK);enter.setOnClickListener(v->commitText());LinearLayout.LayoutParams enterLp=new LinearLayout.LayoutParams(dp(82),dp(50));enterLp.setMargins(dp(3),dp(10),0,dp(5));textRow.addView(enter,enterLp);root.addView(textRow);
        LinearLayout palette=new LinearLayout(this);int[]colors={Color.BLACK,Color.RED,Color.rgb(30,105,255),Color.rgb(20,180,80),Color.rgb(255,145,0)};for(int c:colors){Button cb=button("●",c,c==Color.BLACK?Color.WHITE:Color.BLACK);cb.setOnClickListener(v->{brushColor=c;pad.invalidate();});palette.addView(cb,part());}root.addView(palette);
        LinearLayout tools=new LinearLayout(this);Button brush=button("Кисть: 5",Color.rgb(55,63,82),Color.WHITE);brush.setOnClickListener(v->{brushWidth=brushWidth==5?9:brushWidth==9?14:5;brush.setText("Кисть: "+(int)brushWidth);});Button move=button("Двигать текст",Color.rgb(55,63,82),Color.WHITE);move.setOnClickListener(v->{moveText=!moveText;move.setText(moveText?"Текст: двигаю":"Двигать текст");move.setBackground(round(moveText?Color.rgb(35,180,110):Color.rgb(55,63,82),10));});tools.addView(brush,part());tools.addView(move,part());root.addView(tools);
        liveButton=button("LIVE: выкл",Color.rgb(55,63,82),Color.WHITE);liveButton.setOnClickListener(v->toggleLive());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,dp(7),0,0);root.addView(liveButton,lp);
        LinearLayout actions=new LinearLayout(this);Button clear=button("Очистить",Color.rgb(55,63,82),Color.WHITE);clear.setOnClickListener(v->{pad.strokes.clear();committedText="";pad.invalidate();text.setText("");if(live)sendClear();});Button picture=button("Картинка",Color.rgb(255,201,40),Color.BLACK);picture.setOnClickListener(v->make(false));Button animation=button("Анимация",Color.rgb(255,201,40),Color.BLACK);animation.setOnClickListener(v->make(true));actions.addView(clear,part());actions.addView(picture,part());actions.addView(animation,part());root.addView(actions);
        state=label("",13,Color.rgb(140,230,185));state.setGravity(Gravity.CENTER);root.addView(state,new LinearLayout.LayoutParams(-1,dp(28)));setContentView(root);}

    void toggleLive(){live=!live;if(live){liveButton.setText("LIVE: включён");liveButton.setBackground(round(Color.rgb(35,180,110),10));state.setText("Рисунок идёт на экран сразу");sendClear();}else{liveButton.setText("LIVE: выкл");liveButton.setBackground(round(Color.rgb(55,63,82),10));state.setText("");}}
    void sendClear(){queuePacket(new byte[]{2});}
    void sendStrokeStart(float x,float y){int px=Math.max(0,Math.min(319,Math.round(x))),py=Math.max(0,Math.min(239,Math.round(y)));byte[]p=new byte[5];p[0]=3;p[1]=(byte)px;p[2]=(byte)(px>>8);p[3]=(byte)py;p[4]=(byte)(py>>8);queuePacket(p);}
    void sendLine(float ax,float ay,float bx,float by,int color,float width){int x1=Math.max(0,Math.min(319,Math.round(ax))),y1=Math.max(0,Math.min(239,Math.round(ay))),x2=Math.max(0,Math.min(319,Math.round(bx))),y2=Math.max(0,Math.min(239,Math.round(by)));byte[]p=new byte[13];p[0]=1;p[1]=(byte)x1;p[2]=(byte)(x1>>8);p[3]=(byte)y1;p[4]=(byte)(y1>>8);p[5]=(byte)x2;p[6]=(byte)(x2>>8);p[7]=(byte)y2;p[8]=(byte)(y2>>8);p[9]=(byte)Color.red(color);p[10]=(byte)Color.green(color);p[11]=(byte)Color.blue(color);p[12]=(byte)Math.round(width);queuePacket(p);}
    void queuePacket(byte[]data){liveQueue.execute(()->{try{if(liveSocket==null)liveSocket=new DatagramSocket();if(boardAddress==null)boardAddress=InetAddress.getByName("192.168.4.1");liveSocket.send(new DatagramPacket(data,data.length,boardAddress,4210));}catch(Exception e){runOnUiThread(()->state.setText("LIVE: подключитесь к CYD-PhotoFrame"));}});}
    @Override protected void onDestroy(){live=false;if(liveSocket!=null)liveSocket.close();liveQueue.shutdownNow();super.onDestroy();}

    void commitText(){committedText=text.getText().toString();pad.invalidate();android.view.inputmethod.InputMethodManager keyboard=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);keyboard.hideSoftInputFromWindow(text.getWindowToken(),0);text.clearFocus();state.setText(committedText.length()==0?"Текст убран":"Текст добавлен на холст");}
    void make(boolean gif){final String words=committedText;state.setText(gif?"Создание анимации…":"Создание картинки…");new Thread(()->{try{File f=new File(getCacheDir(),gif?"canvas.gif":"canvas.jpg");if(gif){ByteArrayOutputStream out=new ByteArrayOutputStream();MainActivity.Gif332Encoder enc=new MainActivity.Gif332Encoder(out,320,240,8,false);int units=pad.units()+words.length();int frames=Math.max(2,Math.min(36,units/3+2));for(int i=1;i<=frames;i++){Bitmap frame=pad.render(words,i/(float)frames);enc.addFrame(frame);frame.recycle();}enc.finish();FileOutputStream o=new FileOutputStream(f);o.write(out.toByteArray());o.close();}else{Bitmap frame=pad.render(words,1);FileOutputStream o=new FileOutputStream(f);frame.compress(Bitmap.CompressFormat.JPEG,92,o);o.close();frame.recycle();}Intent result=new Intent();result.putExtra("path",f.getAbsolutePath());result.putExtra("gif",gif);setResult(RESULT_OK,result);runOnUiThread(this::finish);}catch(Exception e){runOnUiThread(()->state.setText("Ошибка: "+e.getMessage()));}}).start();}

    class Stroke {ArrayList<PointF>points=new ArrayList<PointF>();int color;float width;Stroke(int c,float w){color=c;width=w;}}
    class DrawPad extends View {ArrayList<Stroke>strokes=new ArrayList<Stroke>();Paint ink=new Paint(Paint.ANTI_ALIAS_FLAG);PointF lastLivePoint;long lastLiveAt;DrawPad(){super(CreatorActivity.this);setBackgroundColor(Color.WHITE);ink.setStrokeCap(Paint.Cap.ROUND);ink.setStrokeJoin(Paint.Join.ROUND);}
        @Override protected void onMeasure(int widthSpec,int heightSpec){int width=MeasureSpec.getSize(widthSpec);setMeasuredDimension(width,width*3/4);}
        float dragOffsetX,dragOffsetY;boolean resizingText;
        Paint textPaint(String words){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(brushColor);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextSize(textSize);while(p.measureText(words)>300&&p.getTextSize()>14)p.setTextSize(p.getTextSize()-1);return p;}
        float textWidth(){String words=committedText;return Math.max(48,textPaint(words.length()==0?"Текст":words).measureText(words.length()==0?"Текст":words));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);float sx=getWidth()/320f,sy=getHeight()/240f;c.save();c.scale(sx,sy);drawStrokes(c,Integer.MAX_VALUE);drawText(c,committedText,Integer.MAX_VALUE);if(moveText&&committedText.length()>0){float w=textWidth(),h=textSize+12;Paint frame=new Paint(Paint.ANTI_ALIAS_FLAG);frame.setStyle(Paint.Style.STROKE);frame.setStrokeWidth(2);frame.setColor(Color.rgb(30,105,255));c.drawRect(textX-w/2-7,textY-h+3,textX+w/2+7,textY+8,frame);frame.setStyle(Paint.Style.FILL);c.drawCircle(textX+w/2+7,textY+8,7,frame);}c.restore();}
        @Override public boolean onTouchEvent(MotionEvent e){float x=e.getX()*320f/getWidth(),y=e.getY()*240f/getHeight();if(moveText){float w=textWidth(),right=textX+w/2+7,bottom=textY+8;if(e.getAction()==MotionEvent.ACTION_DOWN){resizingText=Math.abs(x-right)<25&&Math.abs(y-bottom)<25;dragOffsetX=x-textX;dragOffsetY=y-textY;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){if(resizingText){textSize=Math.max(14,Math.min(64,14+Math.abs(x-textX)*0.32f));}else{textX=Math.max(8,Math.min(312,x-dragOffsetX));textY=Math.max(textSize,Math.min(232,y-dragOffsetY));}invalidate();if(e.getAction()==MotionEvent.ACTION_UP)resizingText=false;return true;}return true;}if(e.getAction()==MotionEvent.ACTION_DOWN){Stroke s=new Stroke(brushColor,brushWidth);s.points.add(new PointF(x,y));strokes.add(s);lastLivePoint=new PointF(x,y);lastLiveAt=0;if(live)sendStrokeStart(x,y);invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){if(!strokes.isEmpty())strokes.get(strokes.size()-1).points.add(new PointF(x,y));long now=android.os.SystemClock.uptimeMillis();if(live&&lastLivePoint!=null&&(e.getAction()==MotionEvent.ACTION_UP||now-lastLiveAt>=18)){Stroke s=strokes.get(strokes.size()-1);sendLine(lastLivePoint.x,lastLivePoint.y,x,y,s.color,s.width);lastLivePoint=new PointF(x,y);lastLiveAt=now;}invalidate();return true;}return true;}
        int units(){int n=0;for(Stroke s:strokes)n+=s.points.size();return n;}
        Bitmap render(String words,float progress){Bitmap b=Bitmap.createBitmap(320,240,Bitmap.Config.RGB_565);Canvas c=new Canvas(b);c.drawColor(Color.WHITE);int total=units()+words.length(),allowed=(int)(total*progress);int used=drawStrokes(c,allowed);drawText(c,words,Math.max(0,allowed-used));return b;}
        int drawStrokes(Canvas c,int limit){int used=0;for(Stroke s:strokes){ink.setColor(s.color);ink.setStrokeWidth(s.width);for(int i=1;i<s.points.size();i++){if(used>=limit)return used;PointF a=s.points.get(i-1),b=s.points.get(i);c.drawLine(a.x,a.y,b.x,b.y,ink);used++;}}return used;}
        void drawText(Canvas c,String words,int chars){if(words.length()==0||chars<=0)return;String shown=words.substring(0,Math.min(chars,words.length()));c.drawText(shown,textX,textY,textPaint(words));}
    }
    LinearLayout.LayoutParams part(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(50),1);p.setMargins(dp(3),dp(4),dp(3),0);return p;}Button button(String s,int bg,int fg){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(fg);b.setBackground(round(bg,10));return b;}TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}GradientDrawable round(int color,int r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));return g;}int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
}
