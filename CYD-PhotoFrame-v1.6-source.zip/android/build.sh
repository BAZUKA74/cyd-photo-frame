#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TOOLS="$HERE/../android-tools"
JAVA="$TOOLS/jdk/bin/java"
JAVAC="$TOOLS/jdk/bin/javac"
KEYTOOL="$TOOLS/jdk/bin/keytool"
ANDROID_JAR="$TOOLS/platform31/android-12/android.jar"
AAPT="$TOOLS/root/usr/bin/aapt"
ZIPALIGN="$TOOLS/root/usr/bin/zipalign"
APKSIGNER="$TOOLS/root/usr/lib/android-sdk/build-tools/debian/apksigner.jar"
LIBS="$TOOLS/root/usr/lib/aarch64-linux-gnu/android:$TOOLS/root/usr/lib/aarch64-linux-gnu:$TOOLS/root/usr/lib"

rm -rf "$HERE/build"
mkdir -p "$HERE/build/classes" "$HERE/build/dex"
LD_LIBRARY_PATH="$LIBS" "$AAPT" package -f -M "$HERE/AndroidManifest.xml" -I "$ANDROID_JAR" -S "$HERE/res" -F "$HERE/build/resources.apk"
"$JAVAC" -source 8 -target 8 -encoding UTF-8 -cp "$ANDROID_JAR" -d "$HERE/build/classes" $(find "$HERE/src" -name '*.java')
"$JAVA" -cp "$TOOLS/r8.jar" com.android.tools.r8.D8 --lib "$ANDROID_JAR" --output "$HERE/build/dex" $(find "$HERE/build/classes" -name '*.class')
cp "$HERE/build/resources.apk" "$HERE/build/unsigned.apk"
(cd "$HERE/build/dex" && zip -q -j "$HERE/build/unsigned.apk" classes.dex)
LD_LIBRARY_PATH="$LIBS" "$ZIPALIGN" -f 4 "$HERE/build/unsigned.apk" "$HERE/build/aligned.apk"
if [ ! -f "$HERE/debug.keystore" ]; then
  "$KEYTOOL" -genkeypair -keystore "$HERE/debug.keystore" -storepass android -keypass android -alias cyd -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=CYD PhotoFrame, O=Local"
fi
"$JAVA" -jar "$APKSIGNER" sign --ks "$HERE/debug.keystore" --ks-pass pass:android --key-pass pass:android --out "$HERE/build/CYD-PhotoFrame-Samsung-A12.apk" "$HERE/build/aligned.apk"
"$JAVA" -jar "$APKSIGNER" verify --verbose "$HERE/build/CYD-PhotoFrame-Samsung-A12.apk"
