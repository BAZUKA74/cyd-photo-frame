package ru.cyd.photoframe;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Movie;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ScrollView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int PICK = 7;
    private static final int CREATE = 8;
    private static final String CURRENT_VERSION = "1.10";
    private static final String RELEASE_API = "https://api.github.com/repos/BAZUKA74/cyd-photo-frame/releases/latest";
    private Uri selected;
    private String selectedName = "";
    private String selectedType = "";
    private TextView status;
    private ImageView preview;
    private ProgressBar progress;
    private Button send;
    private Spinner rotationChoice, fitChoice;
    private int processRotation, processFit;
    private String localPath;
    private boolean localIsGif;
    private boolean english;

    private String tr(String ru,String en){return english?en:ru;}

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        english=getSharedPreferences("settings",MODE_PRIVATE).getBoolean("english",!Locale.getDefault().getLanguage().equals("ru"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(18));
        root.setBackgroundColor(Color.rgb(16,19,26));

        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("CYD PHOTOFRAME", 27, Color.WHITE);titleRow.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView version=text("v"+CURRENT_VERSION,11,Color.rgb(120,135,160));version.setGravity(Gravity.RIGHT);titleRow.addView(version,new LinearLayout.LayoutParams(dp(46),-2));Button menu=new Button(this);menu.setText("⋮");menu.setTextSize(24);menu.setTextColor(Color.WHITE);menu.setBackgroundColor(Color.TRANSPARENT);menu.setPadding(0,0,0,0);menu.setOnClickListener(v->showAppMenu());titleRow.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(44)));root.addView(titleRow);
        TextView info = text(tr("Android 5.0+ · телефоны и планшеты\nФото, GIF и MP4 → экран 320×240","Android 5.0+ · phones and tablets\nPhotos, GIFs and MP4 → 320×240 display"), 15, Color.rgb(190,200,220));
        info.setPadding(0,dp(8),0,dp(16)); root.addView(info);

        Button wifi = button(tr("1. Подключиться к CYD-PhotoFrame","1. Connect to CYD-PhotoFrame"));
        wifi.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS)));
        root.addView(wifi);

        LinearLayout pickRow=new LinearLayout(this); pickRow.setOrientation(LinearLayout.HORIZONTAL);
        Button gallery = button(tr("Из галереи","Gallery")); gallery.setOnClickListener(v -> chooseFile("image/*",tr("Галерея","Gallery")));
        Button files = button(tr("Из файлов / GIF / MP4","Files / GIF / MP4")); files.setOnClickListener(v -> chooseFile("*/*",tr("Файлы","Files")));
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(54),1); half.setMargins(0,dp(5),dp(4),dp(5)); pickRow.addView(gallery,half);
        LinearLayout.LayoutParams half2=new LinearLayout.LayoutParams(0,dp(54),1); half2.setMargins(dp(4),dp(5),0,dp(5)); pickRow.addView(files,half2); root.addView(pickRow);
        Button creator=button(tr("Рисовать или написать текст","Draw or add text")); creator.setOnClickListener(v -> startActivityForResult(new Intent(this,CreatorActivity.class),CREATE)); root.addView(creator);

        preview = new ImageView(this);
        preview.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(-1, dp(155));
        imageLp.setMargins(0,dp(14),0,dp(8)); root.addView(preview,imageLp);

        status = text(tr("Файл пока не выбран","No file selected"), 15, Color.rgb(160,175,200));
        status.setPadding(dp(14),dp(12),dp(14),dp(12)); status.setBackground(round(Color.rgb(27,32,48),14));
        root.addView(status);
        TextView compact=text(tr("АВТООПТИМИЗАЦИЯ · ДО 1,8 МБ · 12 FPS","AUTO OPTIMIZATION · UP TO 1.8 MB · 12 FPS"),12,Color.rgb(255,201,40)); compact.setPadding(0,dp(15),0,dp(3)); root.addView(compact);
        TextView angleLabel=text(tr("УГОЛ ПОВОРОТА","ROTATION"),12,Color.rgb(190,200,220));angleLabel.setPadding(0,dp(8),0,dp(3));root.addView(angleLabel);
        rotationChoice=spinner(new String[]{"0°","90°","180°","270°"}); root.addView(rotationChoice,new LinearLayout.LayoutParams(-1,dp(58)));
        View settingsGap=new View(this);root.addView(settingsGap,new LinearLayout.LayoutParams(-1,dp(18)));
        TextView fitLabel=text(tr("ЗАПОЛНЕНИЕ ЭКРАНА","SCREEN FIT"),12,Color.rgb(190,200,220));fitLabel.setPadding(0,0,0,dp(3));root.addView(fitLabel);
        fitChoice=spinner(english?new String[]{"Stretch","Fill (crop)","Fit with borders"}:new String[]{"Растянуть","Заполнить (обрезать)","Вписать с полями"}); fitChoice.setSelection(1); root.addView(fitChoice,new LinearLayout.LayoutParams(-1,dp(58)));
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); progress.setVisibility(View.GONE); root.addView(progress,new LinearLayout.LayoutParams(-1,dp(18)));

        send = button(tr("3. Подготовить и отправить","3. Prepare and send")); send.setEnabled(false);
        send.setOnClickListener(v -> prepareAndUpload()); root.addView(send);
        TextView foot = text(tr("Приложение сжимает фото, GIF и MP4 под память платы. Плата должна быть рядом и включена.","The app compresses photos, GIFs and MP4 videos to fit the board memory. Keep the board powered on and nearby."), 13, Color.rgb(130,145,170));
        foot.setPadding(0,dp(12),0,0); root.addView(foot);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
    }

    private void chooseFile(String type,String title) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType(type);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i,title),PICK);
    }

    private void showAppMenu(){final Dialog dialog=new Dialog(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(22),dp(20),dp(22),dp(18));box.setBackground(round(Color.rgb(18,21,29),20));TextView heading=text("CYD PHOTOFRAME",22,Color.WHITE);box.addView(heading);TextView sub=text(tr("Меню приложения","App menu")+"  ·  v"+CURRENT_VERSION,13,Color.rgb(145,160,185));sub.setPadding(0,dp(4),0,dp(14));box.addView(sub);Button language=button(english?"Language: English":"Язык: Русский");language.setOnClickListener(v->{getSharedPreferences("settings",MODE_PRIVATE).edit().putBoolean("english",!english).apply();dialog.dismiss();recreate();});box.addView(language);Button update=button(tr("Проверить обновления","Check for updates"));update.setOnClickListener(v->{dialog.dismiss();checkUpdates();});box.addView(update);Button about=button(tr("О приложении","About"));about.setTextColor(Color.WHITE);about.setBackground(round(Color.rgb(45,51,66),12));about.setOnClickListener(v->{sub.setText(tr("Версия "+CURRENT_VERSION+"  ·  ESP32-2432S028\nФото, GIF, LIVE-рисование и текст","Version "+CURRENT_VERSION+"  ·  ESP32-2432S028\nPhotos, GIFs, LIVE drawing and text"));});box.addView(about);Button close=button(tr("Закрыть","Close"));close.setTextColor(Color.rgb(185,195,215));close.setBackgroundColor(Color.TRANSPARENT);close.setOnClickListener(v->dialog.dismiss());box.addView(close);dialog.setContentView(box);android.view.Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setDimAmount(.72f);w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);}dialog.setOnShowListener(x->{android.view.Window dw=dialog.getWindow();if(dw!=null)dw.setLayout((int)(getResources().getDisplayMetrics().widthPixels*.88f),-2);});dialog.show();}
    private void checkUpdates(){status.setText("Проверка обновлений…");new Thread(()->{HttpURLConnection c=null;try{c=(HttpURLConnection)new URL(RELEASE_API).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(10000);c.setRequestProperty("Accept","application/vnd.github+json");c.setRequestProperty("User-Agent","CYD-PhotoFrame-Android");int code=c.getResponseCode();if(code!=200)throw new Exception("нет доступного релиза");InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[4096];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();JSONObject release=new JSONObject(out.toString("UTF-8"));String tag=release.optString("tag_name","").replaceFirst("^[vV]","");String apk="";JSONArray assets=release.optJSONArray("assets");if(assets!=null)for(int i=0;i<assets.length();i++){JSONObject a=assets.getJSONObject(i);if(a.optString("name").toLowerCase().endsWith(".apk")){apk=a.optString("browser_download_url");break;}}if(apk.length()==0)throw new Exception("APK не найден в релизе");final String found=tag,download=apk;runOnUiThread(()->{status.setText("Проверка завершена");if(isNewer(found,CURRENT_VERSION))new AlertDialog.Builder(this).setTitle("Доступна версия "+found).setMessage("Скачать новый APK с GitHub?").setNegativeButton("Позже",null).setPositiveButton("Скачать",(d,w)->startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(download)))).show();else new AlertDialog.Builder(this).setTitle("Обновлений нет").setMessage("У вас актуальная версия "+CURRENT_VERSION).setPositiveButton("ОК",null).show();});}catch(Exception e){final String message=e.getMessage();runOnUiThread(()->status.setText("Обновление: "+message));}finally{if(c!=null)c.disconnect();}}).start();}
    private boolean isNewer(String remote,String local){try{String[]a=remote.split("\\."),b=local.split("\\.");for(int i=0;i<Math.max(a.length,b.length);i++){int x=i<a.length?Integer.parseInt(a[i].replaceAll("[^0-9]","")):0,y=i<b.length?Integer.parseInt(b[i].replaceAll("[^0-9]","")):0;if(x!=y)return x>y;}}catch(Exception ignored){}return false;}

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if(request==CREATE && result==RESULT_OK && data!=null){localPath=data.getStringExtra("path");localIsGif=data.getBooleanExtra("gif",false);selected=null;selectedName=localIsGif?"drawing.gif":"drawing.jpg";selectedType=localIsGif?"image/gif":"image/jpeg";status.setText(selectedName+"\n"+tr("Создано в редакторе","Created in the editor"));send.setEnabled(true);Bitmap b=BitmapFactory.decodeFile(localPath);if(b!=null)preview.setImageBitmap(b);return;}
        if(request!=PICK || result!=RESULT_OK || data==null || data.getData()==null) return;
        localPath=null; selected=data.getData(); selectedType=getContentResolver().getType(selected);
        if(selectedType==null) selectedType="";
        selectedName=queryName(selected);
        status.setText(selectedName+"\n"+(selectedType.length()>0?selectedType:tr("тип определится автоматически","type will be detected automatically")));
        send.setEnabled(true);
        try {
            if(selectedType.startsWith("video/")) {
                MediaMetadataRetriever m=new MediaMetadataRetriever(); m.setDataSource(this,selected);
                preview.setImageBitmap(m.getFrameAtTime(0)); m.release();
            } else preview.setImageURI(selected);
        } catch(Exception e) { preview.setImageDrawable(null); }
    }

    private String queryName(Uri uri) {
        Cursor c=null; try { c=getContentResolver().query(uri,null,null,null,null);
            if(c!=null && c.moveToFirst()) { int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(n>=0)return c.getString(n); }
        } catch(Exception ignored) {} finally { if(c!=null)c.close(); }
        return "media";
    }

    private void prepareAndUpload() {
        if(selected==null && localPath==null)return; send.setEnabled(false); progress.setVisibility(View.VISIBLE); progress.setProgress(2);
        processRotation=rotationChoice.getSelectedItemPosition()*90; processFit=fitChoice.getSelectedItemPosition();
        status.setText(tr("Подготовка…","Preparing…"));
        final int compression=0;
        new Thread(() -> {
            try {
                byte[] bytes; String filename;
                if(localPath!=null){bytes=readLocal(localPath);filename=localIsGif?"media.gif":"photo.jpg";ui(tr("Отправка созданного файла…","Sending created file…"),70);upload(bytes,filename);ui(tr("Готово — файл показан на экране","Done — file is shown on the display"),100);runOnUiThread(() -> send.setEnabled(true));return;}
                boolean video=selectedType.startsWith("video/") || selectedName.toLowerCase().endsWith(".mp4");
                boolean gif=selectedType.equals("image/gif") || selectedName.toLowerCase().endsWith(".gif");
                if(video) { ui(tr("Преобразование MP4 в GIF…","Converting MP4 to GIF…"),10); bytes=videoToGif(selected,compression); filename="media.gif"; }
                else if(gif) { ui(tr("Оптимизация GIF…","Optimizing GIF…"),10); bytes=optimizeGif(selected,compression); filename="media.gif"; }
                else { ui(tr("Подготовка фотографии…","Preparing photo…"),20); bytes=photoToJpeg(selected); filename="photo.jpg"; }
                if(bytes.length>1950000) throw new Exception(tr("не удалось ужать файл до памяти платы","could not compress the file to fit board memory"));
                ui(tr("Отправка на плату…","Sending to board…"),75); upload(bytes,filename);
                ui(tr("Готово — файл показан на экране","Done — file is shown on the display"),100);
            } catch(Exception e) { ui(tr("Ошибка: ","Error: ")+(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()),0); }
            runOnUiThread(() -> send.setEnabled(true));
        }).start();
    }

    private byte[] readAll(Uri uri) throws Exception {
        InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] b=new byte[16384]; int n; while((n=in.read(b))>0)out.write(b,0,n); in.close(); return out.toByteArray();
    }
    private byte[] readLocal(String path)throws Exception{FileInputStream in=new FileInputStream(new File(path));ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[16384];int n;while((n=in.read(b))>0)out.write(b,0,n);in.close();return out.toByteArray();}

    private byte[] photoToJpeg(Uri uri) throws Exception {
        InputStream in=getContentResolver().openInputStream(uri); Bitmap src=BitmapFactory.decodeStream(in); in.close();
        if(src==null)throw new Exception(tr("не удалось прочитать изображение","could not read the image"));
        Bitmap frame=fit(src); if(frame!=src)src.recycle(); ByteArrayOutputStream out=new ByteArrayOutputStream();
        frame.compress(Bitmap.CompressFormat.JPEG,86,out); frame.recycle(); return out.toByteArray();
    }

    private Bitmap fit(Bitmap src) {
        Bitmap dst=Bitmap.createBitmap(320,240,Bitmap.Config.RGB_565); Canvas c=new Canvas(dst); c.drawColor(Color.BLACK);
        boolean turn=processRotation==90||processRotation==270; float areaW=turn?240:320,areaH=turn?320:240,w,h;
        if(processFit==0){w=areaW;h=areaH;}else{float scale=(processFit==1?Math.max(areaW/src.getWidth(),areaH/src.getHeight()):Math.min(areaW/src.getWidth(),areaH/src.getHeight()));w=src.getWidth()*scale;h=src.getHeight()*scale;}
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);c.save();c.translate(160,120);c.rotate(processRotation);c.drawBitmap(src,null,new android.graphics.RectF(-w/2,-h/2,w/2,h/2),p);c.restore();return dst;
    }

    private byte[] videoToGif(Uri uri,int mode) throws Exception {
        MediaMetadataRetriever m=new MediaMetadataRetriever(); m.setDataSource(this,uri);
        long duration=Long.parseLong(m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
        int[] maxMs={7000,6000,8000}, fps={12,6,8}, limits={1800000,1350000,1750000};
        duration=Math.min(duration,maxMs[mode]); int step=1000/fps[mode]; ByteArrayOutputStream out=new ByteArrayOutputStream(); Gif332Encoder g=new Gif332Encoder(out,320,240,Math.max(2,step/10),false);
        int frames=Math.max(1,(int)(duration/step));
        for(int i=0;i<frames;i++) {
            Bitmap raw=m.getFrameAtTime(i*step*1000L,MediaMetadataRetriever.OPTION_CLOSEST);
            if(raw==null)continue; Bitmap frame=fit(raw); raw.recycle(); g.addFrame(frame); frame.recycle();
            final int pct=10+(int)(55f*(i+1)/frames); ui("Преобразование MP4: "+(i+1)+"/"+frames,pct);
            if(out.size()>limits[mode]-90000)break;
        }
        g.finish(); m.release(); return out.toByteArray();
    }

    private byte[] optimizeGif(Uri uri,int mode) throws Exception {
        byte[] original=readAll(uri); int[] limits={1800000,1350000,1750000};
        if(original.length<=limits[mode])return original;
        Movie movie=Movie.decodeByteArray(original,0,original.length); if(movie==null)throw new Exception("GIF повреждена или не поддерживается");
        int[] maxMs={7000,6000,8000},fps={12,6,8}; int duration=movie.duration(); if(duration<=0)duration=1000; duration=Math.min(duration,maxMs[mode]); int step=1000/fps[mode];
        ByteArrayOutputStream out=new ByteArrayOutputStream(); Gif332Encoder g=new Gif332Encoder(out,320,240,Math.max(2,step/10),false); int frames=Math.max(1,duration/step);
        for(int i=0;i<frames;i++){Bitmap frame=Bitmap.createBitmap(320,240,Bitmap.Config.RGB_565);Canvas c=new Canvas(frame);c.drawColor(Color.BLACK);movie.setTime(i*step);float s=Math.max(320f/movie.width(),240f/movie.height());c.save();c.translate((320-movie.width()*s)/2f,(240-movie.height()*s)/2f);c.scale(s,s);movie.draw(c,0,0);c.restore();g.addFrame(frame);frame.recycle();ui("Сжатие GIF: "+(i+1)+"/"+frames,10+(int)(55f*(i+1)/frames));if(out.size()>limits[mode]-90000)break;}
        g.finish();return out.toByteArray();
    }

    private void upload(byte[] data,String filename) throws Exception {
        String boundary="----CYD"+System.currentTimeMillis(); HttpURLConnection c=(HttpURLConnection)new URL("http://192.168.4.1/upload").openConnection();
        c.setConnectTimeout(7000); c.setReadTimeout(20000); c.setDoOutput(true); c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
        OutputStream o=c.getOutputStream(); String head="--"+boundary+"\r\nContent-Disposition: form-data; name=\"media\"; filename=\""+filename+"\"\r\nContent-Type: application/octet-stream\r\n\r\n";
        o.write(head.getBytes("UTF-8")); int pos=0; while(pos<data.length){int n=Math.min(16384,data.length-pos);o.write(data,pos,n);pos+=n; final int pct=75+(int)(24f*pos/data.length);ui("Отправка: "+(pos/1024)+" КБ",pct);} o.write(("\r\n--"+boundary+"--\r\n").getBytes("UTF-8")); o.close();
        int code=c.getResponseCode(); InputStream in=code<400?c.getInputStream():c.getErrorStream(); ByteArrayOutputStream response=new ByteArrayOutputStream(); if(in!=null){byte[] b=new byte[1024];int n;while((n=in.read(b))>0)response.write(b,0,n);in.close();} c.disconnect();
        if(code!=200)throw new Exception("плата ответила "+code+": "+response.toString("UTF-8"));
    }

    private void ui(final String s,final int p){runOnUiThread(() -> {status.setText(s);progress.setProgress(p);if(p==100)progress.setVisibility(View.GONE);});}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setTextColor(Color.rgb(20,18,8));b.setAllCaps(false);b.setBackground(round(Color.rgb(255,201,40),12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(5),0,dp(5));b.setLayoutParams(lp);return b;}
    private Spinner spinner(String[] items){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,items);s.setAdapter(a);s.setPadding(dp(14),0,dp(14),0);s.setBackground(round(Color.rgb(230,234,242),10));return s;}
    private GradientDrawable round(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}

    static class Gif332Encoder {
        final ByteArrayOutputStream out; final int w,h,delay; final boolean compact; boolean ended;
        Gif332Encoder(ByteArrayOutputStream o,int width,int height,int delay,boolean compact) throws Exception {out=o;w=width;h=height;this.delay=delay;this.compact=compact;ascii("GIF89a");word(w);word(h);write(0xF7);write(0);write(0);palette();write(0x21);write(0xFF);write(11);ascii("NETSCAPE2.0");write(3);write(1);word(0);write(0);}
        void palette(){for(int i=0;i<256;i++){int r,g,b;if(compact){r=(i>>4)&3;g=(i>>2)&3;b=i&3;write(r*255/3);write(g*255/3);write(b*255/3);}else{r=(i>>5)&7;g=(i>>2)&7;b=i&3;write(r*255/7);write(g*255/7);write(b*255/3);}}}
        void addFrame(Bitmap bm)throws Exception{byte[] idx=new byte[w*h];int[] row=new int[w];int at=0;for(int y=0;y<h;y++){bm.getPixels(row,0,w,0,y,w,1);for(int x=0;x<w;x++){int c=row[x];idx[at++]=(byte)(compact?((Color.red(c)>>6)<<4)|((Color.green(c)>>6)<<2)|(Color.blue(c)>>6):((Color.red(c)>>5)<<5)|((Color.green(c)>>5)<<2)|(Color.blue(c)>>6));}}write(0x21);write(0xF9);write(4);write(4);word(delay);write(0);write(0);write(0x2C);word(0);word(0);word(w);word(h);write(0);write(8);lzw(idx);}
        void lzw(byte[] data)throws Exception{BitPacker bits=new BitPacker();HashMap<Integer,Integer>d=new HashMap<Integer,Integer>(4096);int clear=256,end=257,next=258,size=9;bits.code(clear,size);int prefix=data[0]&255;for(int i=1;i<data.length;i++){int c=data[i]&255,key=(prefix<<8)|c;Integer found=d.get(key);if(found!=null){prefix=found;}else{bits.code(prefix,size);if(next<4096){d.put(key,next++);/* Decoder builds the same table one emitted code later. */if(next>(1<<size)&&size<12)size++;}else{bits.code(clear,size);d.clear();next=258;size=9;}prefix=c;}}bits.code(prefix,size);bits.code(end,size);byte[] packed=bits.done();for(int p=0;p<packed.length;){int n=Math.min(255,packed.length-p);write(n);out.write(packed,p,n);p+=n;}write(0);}
        void finish(){if(!ended){write(0x3B);ended=true;}}
        void word(int v){write(v&255);write((v>>8)&255);}void write(int v){out.write(v);}void ascii(String s)throws Exception{out.write(s.getBytes("US-ASCII"));}
        static class BitPacker{ByteArrayOutputStream o=new ByteArrayOutputStream();int cur,bits;void code(int v,int n){cur|=v<<bits;bits+=n;while(bits>=8){o.write(cur&255);cur>>>=8;bits-=8;}}byte[]done(){if(bits>0)o.write(cur&255);return o.toByteArray();}}
    }
}
