# CYD PhotoFrame

**English** · [Русский](README_RU.md)

Firmware and an Android app for the ESP32-2432S028 / HW-458 display board.

> [!IMPORTANT]
> Similar-looking boards may use a different display controller, pinout, touchscreen, backlight circuit, or Flash size. Do not blindly flash the provided binary onto another board model. You can adapt the source code manually or with the help of AI—provide the exact board marking, display controller, and pinout.

Features:

- upload photos, GIFs, and MP4 videos over Wi-Fi;
- prepare and compress media on Android;
- drawing and animated text;
- real-time LIVE drawing on the display;
- touch menu, image rotation, and automatic brightness;
- application update checks through GitHub Releases.
- Russian and English application interface with a remembered language choice.

## Installing the Android app

Download the APK from the Releases section. To update an existing installation, the new APK must be signed with the same key as the installed version.

## Source code

- `firmware/` — PlatformIO project for ESP32-2432S028 / HW-458;
- `android/` — Android application source code;
- `ADAPTATION.md` — guide for porting the firmware to another ESP32 board;
- a complete source archive is also attached to each release.

The project is open for modification. Before adapting it, create a backup of your board's original Flash contents.

## Signing-key security

The application's private signing key is intentionally excluded from the repository and must never be published. Without the original key, Android will not allow a new APK to update an existing installation.
